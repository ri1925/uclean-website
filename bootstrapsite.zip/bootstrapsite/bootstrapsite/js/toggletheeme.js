document.getElementById('toggleTheme').addEventListener('click', () => {
  document.documentElement.classList.toggle('dark-theme');
});
